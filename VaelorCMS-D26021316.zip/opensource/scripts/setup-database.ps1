# VaelorCMS 数据库安装脚本 (Windows)
# 优先安装 MariaDB 8.x，若失败则尝试 MySQL 8.x

$ErrorActionPreference = "Stop"

Write-Host "=== VaelorCMS 数据库安装 ===" -ForegroundColor Cyan
Write-Host ""

# 1. 尝试安装 MariaDB 8.x
Write-Host "[1/2] 尝试通过 winget 安装 MariaDB 8.x..." -ForegroundColor Yellow
try {
    winget install MariaDB.Server --source winget --accept-package-agreements --accept-source-agreements
    Write-Host "MariaDB 安装成功！" -ForegroundColor Green
    exit 0
} catch {
    Write-Host "MariaDB 安装失败: $_" -ForegroundColor Red
}

# 2. 尝试安装 MySQL 8.x
Write-Host ""
Write-Host "[2/2] 尝试通过 winget 安装 MySQL 8.x..." -ForegroundColor Yellow
try {
    winget install Oracle.MySQL --source winget --accept-package-agreements --accept-source-agreements
    Write-Host "MySQL 安装成功！" -ForegroundColor Green
    exit 0
} catch {
    Write-Host "MySQL 安装失败: $_" -ForegroundColor Red
}

Write-Host ""
Write-Host "自动安装失败。请手动安装：" -ForegroundColor Yellow
Write-Host "  - MariaDB 8.x: https://mariadb.org/download/" -ForegroundColor White
Write-Host "  - MySQL 8.x:   https://dev.mysql.com/downloads/mysql/" -ForegroundColor White
Write-Host ""
Write-Host "安装后请创建数据库和用户，并配置 config/config.ini" -ForegroundColor White
