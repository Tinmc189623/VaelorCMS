#!/bin/sh
# VaelorCMS 容器/平台启动脚本
set -e
cd /app
# 迁移（跳过检查）
python main.py migrate --noinput --skip-checks 2>/dev/null || true
# 启动
exec python main.py --prod
