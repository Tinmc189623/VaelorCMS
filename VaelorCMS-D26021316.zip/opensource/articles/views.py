from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from .models import Article


def index(request):
    if request.user.is_authenticated:
        qs = Article.objects.filter(Q(status='published') | Q(user=request.user))
    else:
        qs = Article.objects.filter(status='published')
    category = request.GET.get('category', '').strip()
    if category:
        qs = qs.filter(category=category)
    articles = qs.select_related('user').order_by('-id')[:100]
    categories = list(Article.objects.filter(status='published').exclude(category='').values_list('category', flat=True).distinct()[:20])
    return render(request, 'articles/index.html', {'articles': articles, 'categories': categories, 'current_category': category})


def detail(request, pk):
    article = get_object_or_404(Article.objects.select_related('user'), pk=pk)
    can_view = article.status == 'published' or (request.user.is_authenticated and (article.user_id == request.user.id or request.user.role == 'admin'))
    if not can_view:
        from django.http import HttpResponseForbidden
        return HttpResponseForbidden('无权访问')
    from site_app.seo_middleware import set_request_seo
    content = article.content or ''
    desc = content[:160] + ('...' if len(content) > 160 else '')
    set_request_seo(request, title=article.title, description=desc, keywords=article.tags)
    return render(request, 'articles/detail.html', {'article': article})


@login_required
def create(request):
    return render(request, 'articles/form.html', {'article': None})


@login_required
def edit(request, pk):
    article = get_object_or_404(Article, pk=pk)
    if article.user_id != request.user.id and request.user.role != 'admin':
        from django.http import HttpResponseForbidden
        return HttpResponseForbidden('无权编辑')
    return render(request, 'articles/form.html', {'article': article})


@login_required
def save_article(request):
    if request.method != 'POST':
        return redirect('articles_index')
    pk = request.POST.get('id')
    title = request.POST.get('title', '').strip()
    content = request.POST.get('content', '').strip()
    action = request.POST.get('action', 'save')
    status = 'published' if action == 'publish' else request.POST.get('status', 'draft')
    tags = request.POST.get('tags', '').strip()
    category = request.POST.get('category', '').strip()
    if not title or not content:
        messages.error(request, '标题和内容必填')
        if pk:
            return redirect('article_edit', pk=pk)
        return redirect('article_create')
    if pk:
        article = get_object_or_404(Article, pk=pk)
        if article.user_id != request.user.id and request.user.role != 'admin':
            from django.http import HttpResponseForbidden
            return HttpResponseForbidden('无权编辑')
        article.title, article.content, article.status, article.tags, article.category = title, content, status, tags, category
        article.save()
        return redirect('article_detail', pk=pk)
    else:
        article = Article.objects.create(user=request.user, title=title, content=content, status=status, tags=tags, category=category)
        return redirect('article_detail', pk=article.pk)
