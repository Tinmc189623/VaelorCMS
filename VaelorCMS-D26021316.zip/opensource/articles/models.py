"""文章 - 对应原 articles 表"""
from django.db import models
from django.conf import settings


class Article(models.Model):
    STATUS_CHOICES = [('draft', '草稿'), ('published', '已发布')]
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='articles')
    title = models.CharField(max_length=255)
    content = models.TextField()
    status = models.CharField(max_length=16, default='draft', choices=STATUS_CHOICES)
    tags = models.CharField(max_length=255, default='', blank=True)
    category = models.CharField(max_length=128, default='', blank=True)
    scheduled_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True, null=True)

    class Meta:
        db_table = 'articles'
        ordering = ['-id']
