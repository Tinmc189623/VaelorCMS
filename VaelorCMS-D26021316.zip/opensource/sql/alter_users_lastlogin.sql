-- 为已有 users 表添加 last_login（Django AbstractBaseUser 需要）
-- 若表已存在，运行: mysql -u vaelor_user -p vaelor_cms < sql/alter_users_lastlogin.sql
ALTER TABLE users ADD COLUMN IF NOT EXISTS last_login datetime NULL;
