-- ============================================
-- 已有数据库升级：为 users 表增加 role 字段
-- 执行后需在数据库中手动将某个用户设为管理员，例如：
--   UPDATE users SET role = 'admin' WHERE username = '你的管理员账号';
-- ============================================
SET NAMES utf8mb4;

ALTER TABLE `users`
  ADD COLUMN `role` varchar(20) NOT NULL DEFAULT 'user' COMMENT 'user=普通用户, admin=管理员' AFTER `email`,
  ADD KEY `idx_role` (`role`);
