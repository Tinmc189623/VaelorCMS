-- ============================================
-- 数据库索引优化建议
-- 用于提升查询性能
-- ============================================

SET NAMES utf8mb4;

-- --------------------------------------------
-- 为 users 表添加复合索引
-- --------------------------------------------
-- 用于管理员后台用户列表（按ID排序）
ALTER TABLE `users` ADD INDEX `idx_id_role` (`id`, `role`);

-- --------------------------------------------
-- 为 bbs_posts 表添加复合索引
-- --------------------------------------------
-- 用于管理员后台帖子列表（按ID降序）
ALTER TABLE `bbs_posts` ADD INDEX `idx_id_user` (`id` DESC, `user_id`);

-- --------------------------------------------
-- 为 code_snippets 表添加复合索引
-- --------------------------------------------
-- 用于管理员后台代码列表（按ID降序）
ALTER TABLE `code_snippets` ADD INDEX `idx_id_user` (`id` DESC, `user_id`);

-- --------------------------------------------
-- 为 admin_logs 表添加复合索引
-- --------------------------------------------
-- 用于日志查询（按时间倒序）
ALTER TABLE `admin_logs` ADD INDEX `idx_created_action` (`created_at` DESC, `action`);
-- 用于按用户查询日志
ALTER TABLE `admin_logs` ADD INDEX `idx_user_created` (`user_id`, `created_at` DESC);
