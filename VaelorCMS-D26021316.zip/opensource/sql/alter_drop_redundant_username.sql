-- ============================================
-- 已有数据库升级：去掉 bbs_posts / code_snippets 冗余 username
-- 作者名统一从 users 表 JOIN 获取，保证与用户表一致
-- 执行前请备份。仅当表中仍存在 username 列时执行（新安装已无该列，勿执行）。
-- ============================================
SET NAMES utf8mb4;

ALTER TABLE `bbs_posts` DROP COLUMN `username`;
ALTER TABLE `code_snippets` DROP COLUMN `username`;
