-- ============================================
-- 管理员操作日志表
-- 记录管理员的所有敏感操作
-- ============================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `admin_logs`;
CREATE TABLE `admin_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL DEFAULT '0',
  `username` varchar(64) NOT NULL DEFAULT '',
  `action` varchar(32) NOT NULL DEFAULT '' COMMENT '操作类型：delete_bbs, delete_code, set_role',
  `target` varchar(255) NOT NULL DEFAULT '' COMMENT '操作目标描述',
  `target_id` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '目标ID',
  `ip_address` varchar(45) NOT NULL DEFAULT '' COMMENT '操作者IP地址',
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_action` (`action`),
  KEY `idx_created_at` (`created_at`),
  KEY `idx_target_id` (`target_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='管理员操作日志';

SET FOREIGN_KEY_CHECKS = 1;
