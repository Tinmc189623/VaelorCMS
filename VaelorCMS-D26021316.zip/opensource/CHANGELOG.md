# 更新日志

> 越往上版本越新，越往下版本越旧

## Demo-26.02.13.26

### 优化

- **项目定位**：强调现代 CMS、用户高度自定义与用户自由，移除老旧浏览器兼容代码
- **README / About**：更新项目描述与功能列表

### 新增

- **站点全局 Aero 特效**：body.aero 时启用增强玻璃效果，可配置开关与模糊强度
- **定制化支持**：管理员可设置 Aero 开关、模糊强度、强调色覆盖、自定义 CSS 片段
- **模块化 CSS 架构**：`assets/css/` 拆分为 _variables、_base、_aero、_layout、_components、_admin 模块

### 安全补丁

- **Session/CSRF Cookie**：HttpOnly、SameSite=Lax；HTTPS 下 Secure（`DJANGO_HTTPS=1`）
- **强制 HTTPS**：开启后 HTTP→HTTPS 301 重定向，响应添加 HSTS 头
- **反向代理**：`SECURE_PROXY_SSL_HEADER` 支持 `X-Forwarded-Proto`
- **自定义页面 XSS 防护**：HTML 内容经 `html_sanitizer` 净化（移除 script、iframe、on* 事件等）
- **SECRET_KEY 校验**：生产环境弱密钥时发出警告

### 新增

- **自定义页面**：Page 模型，`/p/<slug>/` 访问，Django 后台管理，可勾选「在导航栏显示」
- **FAQ 页面**：`/faq/` 常见问题，分类展示账号、发帖、个人设置、安全、管理员等
- **FAQ 文档**：`docs/FAQ.md` 完整 FAQ 文档
- **文章分类筛选**：文章列表支持 `?category=` 按分类筛选，分类导航
- **API 文章列表**：`GET /api/v1/articles/?category=` 返回最近 50 篇已发布文章
- **论坛审核**：开启「论坛需审核」后新帖待审，管理员在帖子管理中点击「通过」
- **游客发帖**：开启「游客可发帖」后未登录用户可发帖（显示匿名）
- **自定义页面 HTML**：Page 模型 `content_is_html` 字段，勾选后内容按 HTML 渲染
- **404/500 页面**：自定义错误页，`templates/404.html`、`templates/500.html`

### 优化

- **main.py 启动修复**：`execute_from_command_line` 传入正确脚本路径，解决闪退
- **界面排版**：防止横向溢出、列表项换行、管理表格列数修正、表单溢出处理
- **首页**：增加文章、FAQ、发布文章（登录）、用户中心（登录）入口
- **搜索**：使用 list-wrap 样式，优化空结果提示
- **文章发布**：新增「发布文章」快捷按钮，一键保存为已发布
- **Sitemap**：BbsPost 仅包含已审核帖子，新增 PageSitemap

### 文档

- ROUTES.md 补充自定义页面、FAQ 路由
- API.md 补充 articles 接口
- ADMIN_GUIDE.md 补充论坛审核、游客发帖说明
- README 补充 FAQ 文档链接

## Demo-26.02.13.25

### 新增

- **主题开发规范**：`docs/DEV_THEME_SPEC.md`，规范目录结构、info.ini、CSS 变量、版本号、禁止事项
- **贡献指南**：`docs/CONTRIBUTING.md`，提交规范、代码规范、许可证说明
- **代码规范**：`docs/CODE_STYLE.md`，Python、模板、安全、文档约定
- **API 限流**：`/api/v1/` 按 IP 限流，可配置 `api_rate_limit`（次/分钟），超限返回 429，健康检查不限流
- **安全响应头**：Referrer-Policy、Permissions-Policy、X-Content-Type-Options、X-Frame-Options
- **密码特殊字符**：可选 `require_password_special`，要求密码含 !@#$%^&* 等
- **密码校验统一**：`users/password_validators.py`，注册与修改密码共用同一校验逻辑

### 安全

- 安全响应头中间件，增强 XSS、点击劫持等防护
- 密码策略增强：支持强制特殊字符
- 管理员设置新增「API 限流」「密码须含特殊字符」

### 许可证

- 采用 **GNU AGPL 3.0** 许可证，LICENSE 文件含完整版权声明与许可条款

### 文档

- SECURITY.md 补充 API 限流、响应头、密码策略说明
- API.md 补充限流说明
- ADMIN_GUIDE.md 补充新安全设置项
- README 增加文档链接

## Demo-26.02.13.24

### 新增

- **文章 RSS 订阅**：`/articles/feed/` 提供 RSS 2.0 订阅，输出最近 50 篇已发布文章，站点头部增加 RSS 链接

### 安全

- **登录失败锁定**：按 IP 记录失败次数，超过 `login_max_attempts` 后锁定 `login_lockout_minutes` 分钟，支持 X-Forwarded-For 代理场景

## Demo-26.02.13.23

### 新增

- **主题系统**：`themes/<id>/` 目录，支持多主题切换，内置深色主题
- **插件系统**：基于钩子（head_extra、nav_extra、footer_extra 等），可注入 HTML
- **SEO 优化**：meta、canonical、Open Graph、sitemap.xml、动态 robots.txt、文章 Schema.org
- **开发者文档**：DEV_THEME.md、DEV_PLUGIN.md、DEV_README.md，口语化易读
- **API 文档**：补充 sitemap、robots，对开发者友好
- **阅读体验**：文章页阅读时间估算、语义化 HTML、时间标签

### 优化

- 管理员设置新增「主题」「SEO」标签
- 文章详情页 SEO：标题、描述、关键词、结构化数据
- 模板支持 `request.page_title`、`request.page_description` 等

## Demo-26.02.13.22

- 搜索支持文章模块
- CSRF 可信来源配置（环境变量、config.ini），解决 HTTPS 部署 403
- 安装向导：端口校验、config 写入安全
- 版本号统一、管理后台与 API 补充文章统计
- 文档：云平台部署通用化，示例仅保留在文档

## Demo-26.02.13.21

### 新增

- 用户设置：资料（昵称、简介、头像、隐私、通知、偏好）、修改密码、账户与安全（登出其他设备）
- 管理员设置：站点（名称、描述、关键词、时区、语言）、安全（登录限制、密码策略、会话、HTTPS）、用户（注册开关、邮箱验证）、内容（论坛审核、游客发帖、文章评论）、维护模式
- SiteSetting 模型与 settings_service，数据库存储可编辑设置
- UserProfile 模型，扩展用户资料与偏好
- 维护模式中间件，管理员可正常访问

### 安全

- 注册与密码修改遵循管理员配置的密码策略（最小长度、强密码）
- 关闭注册时禁止新用户注册
- 登出其他设备仅清除当前用户会话

## Demo-26.02.13.20

- 技术栈迁移：PHP → Django 4，保留 config.ini、assets、sql
- 应用：users、bbs、snippets、articles、site_app、install_app
- 路由：/、/bbs/、/code/、/articles/、/users/、/search/、/admin-panel/、/api/v1/、/install/
- Web 安装向导：许可协议 → 环境检测 → 数据库配置 → 站点配置 → 执行安装
- 健康检查 `/api/v1/health/`、升级接口 `/api/v1/upgrade/`
- 统一品牌 VaelorCMS，配置项 VAELOR_SESS、vaelor_

## Demo-26.02.13.19（初始版本）

- 基于 PHP + MySQL 搭建的 CMS
- 用户、论坛、代码分享、文章、搜索、管理后台
- 路径统一使用 .php，子域名路由（www、bbs、m）
- 配置：config/config.ini，文档：ROUTES.md、API.md、DEPLOYMENT.md
