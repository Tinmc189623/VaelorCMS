# 安全策略

## 认证与会话

- 密码 bcrypt 哈希（Django 默认）
- 登录后 session_regenerate_id（防会话固定）
- Session/CSRF Cookie：HttpOnly、SameSite=Lax，HTTPS 下 Secure（需设置 `DJANGO_HTTPS=1`）
- 登录失败锁定：按 IP 限流，可配置 `login_max_attempts`、`login_lockout_minutes`
- 密码策略：最小长度、强密码（字母+数字）、可选特殊字符要求

## 输入与输出

- XSS：Django 模板自动转义；自定义页面 HTML 经 `html_sanitizer` 净化后输出
- SQL：ORM 预编译
- CSRF：Django 内置表单与中间件校验，Cookie HttpOnly

## 强制 HTTPS

- 管理员开启「强制 HTTPS」后，HTTP 请求将 301 重定向至 HTTPS
- HTTPS 响应添加 `Strict-Transport-Security`（HSTS）
- 反向代理需设置 `X-Forwarded-Proto: https`，Django 已配置 `SECURE_PROXY_SSL_HEADER`

## API 限流

- `/api/v1/` 接口按 IP 限流，默认 60 次/分钟，可配置 `api_rate_limit`（0=不限）
- 健康检查 `/api/v1/health/` 不限流

## 响应头

- X-Content-Type-Options: nosniff
- X-Frame-Options: DENY
- Referrer-Policy: strict-origin-when-cross-origin
- Permissions-Policy: 限制 geolocation、microphone、camera
- Strict-Transport-Security（HTTPS 时）

## 访问控制

- 管理后台：`@staff_member_required`，仅 role=admin
- 禁止直接访问 config/、includes/

## 生产清单

- HTTPS、DEBUG=False、ALLOWED_HOSTS 正确
- CSRF_TRUSTED_ORIGINS 配置（HTTPS 必填）
- 设置 `DJANGO_HTTPS=1` 启用 Cookie Secure
- 设置 `DJANGO_SECRET_KEY` 强随机值（避免默认 dev-secret）
- 数据库强密码、定期备份
