# VaelorCMS 安装与配置说明

本文档为开源发布版专用，提供完整安装步骤及**所有需要修改的配置项**。

---

## 一、环境要求

| 项目 | 要求 |
|------|------|
| Python | 3.9+ |
| MySQL | 5.7+ 或 MariaDB 10.2+ |
| 操作系统 | Windows / Linux / macOS |

---

## 二、快速安装（Web 向导，推荐）

### 1. 创建虚拟环境并安装依赖

```bash
cd /path/to/VaelorCMS
python -m venv venv

# Windows:
venv\Scripts\activate
# Linux / macOS:
source venv/bin/activate

pip install -r requirements.txt
```

### 2. 初始化并启动

```bash
python main.py migrate
python main.py
```

### 3. 访问安装向导

浏览器打开 `http://127.0.0.1:8000/`，按向导完成：许可协议 → 环境检测 → 数据库配置 → 站点配置 → 执行安装。

### 4. 安装后重启

```bash
# 停止服务 (Ctrl+C)，然后：
python main.py
```

### 5. 生产环境收集静态文件

```bash
python main.py collectstatic --noinput
```

---

## 三、手动安装（需修改的配置）

### 1. 复制配置文件

```bash
cp config/config.ini.sample config/config.ini
```

### 2. 编辑 `config/config.ini`（必改项）

| 配置项 | 位置 | 说明 | 示例 |
|--------|------|------|------|
| `host` | [database] | MySQL 主机 | `127.0.0.1` |
| `port` | [database] | MySQL 端口 | `3306` |
| `dbname` | [database] | 数据库名（需事先创建） | `vaelor_cms` |
| `username` | [database] | 数据库用户名 | `vaelor_user` |
| `password` | [database] | 数据库密码 | **必填** |
| `name` | [site] | 站点名称 | `我的站点` |
| `trusted_origins` | [site] | HTTPS 部署时 CSRF 可信来源，逗号分隔 | `https://www.example.com` |

**示例：**

```ini
[database]
host = 127.0.0.1
port = 3306
dbname = vaelor_cms
username = vaelor_user
password = 你的数据库密码
charset = utf8mb4

[site]
name = 我的站点
base_url = /
session_name = VAELOR_SESS
cookie_path = /
trusted_origins = https://www.example.com
```

### 3. 创建安装锁并迁移

```bash
# Linux / macOS
touch config/installed.lock

# Windows (PowerShell)
New-Item config/installed.lock -ItemType File

python main.py migrate
python main.py createsuperuser
```

---

## 四、环境变量（可选，覆盖 config.ini）

| 变量 | 说明 | 生产环境建议 |
|------|------|--------------|
| `DJANGO_SECRET_KEY` | Django 密钥 | **必设** 强随机字符串 |
| `DJANGO_DEBUG` | 调试模式，`1`=开 | 生产设为 `0` |
| `DJANGO_HTTPS` | 启用 Secure Cookie | HTTPS 部署设为 `1` |
| `ALLOWED_HOSTS` | 允许的主机，逗号分隔 | 如 `www.example.com` |
| `DB_HOST` | 数据库主机 | 覆盖 config.ini |
| `DB_PORT` | 数据库端口 | 覆盖 config.ini |
| `DB_NAME` | 数据库名 | 覆盖 config.ini |
| `DB_USER` | 数据库用户 | 覆盖 config.ini |
| `DB_PASSWORD` | 数据库密码 | 覆盖 config.ini |
| `CSRF_TRUSTED_ORIGINS` | CSRF 可信来源 | 如 `https://www.example.com` |

---

## 五、config.ini 完整配置说明

### [database]
- `host`：MySQL 主机
- `port`：端口，默认 3306
- `dbname`：数据库名
- `username`：用户名
- `password`：密码
- `charset`：字符集，建议 utf8mb4

### [site]
- `name`：站点名称
- `base_url`：站点根路径，通常 `/`
- `session_name`：Session Cookie 名
- `cookie_path`：Cookie 路径
- `trusted_origins`：HTTPS 反向代理时必填，逗号分隔

### [security]
- `login_max_attempts`：登录失败次数上限（默认 5）
- `login_lockout_minutes`：锁定分钟数（默认 15）
- `force_https`：强制 HTTPS，`1` 启用

### [limits]
- `list_limit`：列表每页数量
- `bbs_content_max`：论坛帖子最大字符数
- `code_snippet_max`：代码片段最大字符数

### [pagination]
- `per_page`：默认每页条数

### [cache]
- `driver`：`redis` 或留空（不用缓存）
- `host` / `port` / `prefix`：Redis 连接

### [performance]
- `static_cache_seconds`：静态资源缓存秒数
- `gzip`：Gzip 压缩，`1` 启用

---

## 六、生产环境部署要点

1. **SECRET_KEY**：设置 `DJANGO_SECRET_KEY` 环境变量，不要用默认值
2. **DEBUG**：`DJANGO_DEBUG=0`
3. **HTTPS**：`DJANGO_HTTPS=1`，配置 `trusted_origins`
4. **ALLOWED_HOSTS**：限制为实际域名
5. **Nginx**：反向代理到 `127.0.0.1:8000`，静态文件指向 `staticfiles/`
6. **数据库**：使用强密码，定期备份

详见 `docs/DEPLOYMENT.md`。

---

## 七、目录与文件说明

| 路径 | 说明 |
|------|------|
| `config/config.ini` | 业务配置（从 config.ini.sample 复制，含敏感信息） |
| `config/config.ini.sample` | 配置模板，不含敏感信息 |
| `config/installed.lock` | 安装锁，存在则跳过安装向导 |
| `storage/uploads/` | 用户上传文件目录，需可写 |
| `staticfiles/` | collectstatic 输出目录 |

---

## 八、常见问题

- **数据库连接失败**：检查 MySQL 是否启动、config.ini 是否正确、数据库是否已创建
- **安装后 404**：必须重启应用服务
- **重新安装**：删除 `config/config.ini` 和 `config/installed.lock` 后重启
