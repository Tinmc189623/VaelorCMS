"""
VaelorCMS 版本号 - 用于升级接口、页脚展示
"""
__version__ = 'Demo-26.02.13.26'
