from django.contrib import admin
from django.utils.html import format_html
from .models import Page


@admin.register(Page)
class PageAdmin(admin.ModelAdmin):
    list_display = ('slug', 'title', 'content_is_html', 'is_published', 'show_in_nav', 'order', 'updated_at', 'view_link')
    list_editable = ('is_published', 'show_in_nav', 'order')
    search_fields = ('slug', 'title', 'content')
    prepopulated_fields = {'slug': ('title',)}

    def view_link(self, obj):
        from django.urls import reverse
        url = reverse('page_detail', args=[obj.slug])
        return format_html('<a href="{}" target="_blank">预览</a>', url)
    view_link.short_description = '预览'
