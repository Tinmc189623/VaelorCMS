"""
HTML 净化 - 自定义页面 content_is_html 时防 XSS
移除 script、iframe、object、embed、form、on* 事件等危险内容
"""
import re
import html

# 危险标签（含内容） - script, style 等
DANGEROUS_BLOCK = re.compile(
    r'<(script|style|iframe|object|embed|form)[^>]*>.*?</\1>',
    re.IGNORECASE | re.DOTALL
)
# 危险自闭合或空标签
DANGEROUS_TAG = re.compile(
    r'<(script|iframe|object|embed|input|button|textarea|select|meta|link|base)[^>]*/?>',
    re.IGNORECASE
)
# on* 事件属性
ON_EVENT = re.compile(r'\s+on\w+\s*=\s*["\'][^"\']*["\']', re.IGNORECASE)
# javascript:/data:/vbscript: 等危险协议
JS_PROTO = re.compile(r'(href|src)\s*=\s*["\']\s*(javascript|data|vbscript)\s*:[^"\']*["\']', re.IGNORECASE)


def sanitize_html(html_str):
    """
    净化 HTML，移除危险标签与事件，防止 XSS。
    若净化失败则返回转义后的纯文本。
    """
    if not html_str or not isinstance(html_str, str):
        return ''
    try:
        s = html_str
        # 移除危险块
        s = DANGEROUS_BLOCK.sub('', s)
        s = DANGEROUS_TAG.sub('', s)
        # 移除 on* 事件
        s = ON_EVENT.sub('', s)
        # 移除 href="javascript:..." 等危险协议，替换为 href="#"
        s = JS_PROTO.sub('href="#"', s)
        return s
    except Exception:
        return html.escape(html_str)
