from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.admin.views.decorators import staff_member_required
from django.db.models import Q
from bbs.models import BbsPost
from snippets.models import CodeSnippet
from articles.models import Article
from users.models import User
from .models import AdminLog


def home(request):
    return render(request, 'home.html')


def robots_txt(request):
    """动态 robots.txt，注入 sitemap URL"""
    from django.http import HttpResponse
    from .settings_service import get
    base = get('seo_canonical_base', '').rstrip('/')
    sitemap_line = f'Sitemap: {base}/sitemap.xml\n' if base else '# Sitemap: https://your-domain.com/sitemap.xml\n'
    content = f"""User-agent: *
Allow: /
Disallow: /admin/
Disallow: /install/

{sitemap_line}"""
    return HttpResponse(content, content_type='text/plain')


def search(request):
    q = request.GET.get('q', '').strip()
    results = {}
    if q:
        results['bbs'] = BbsPost.objects.filter(Q(title__icontains=q) | Q(content__icontains=q)).select_related('user')[:20]
        results['code'] = CodeSnippet.objects.filter(Q(title__icontains=q) | Q(code__icontains=q)).select_related('user')[:20]
        results['articles'] = Article.objects.filter(
            Q(title__icontains=q) | Q(content__icontains=q),
            status='published'
        ).select_related('user')[:20]
    return render(request, 'search.html', {'q': q, 'results': results})


def about(request):
    return render(request, 'about.html')


def help_page(request):
    return render(request, 'help.html')


def faq(request):
    return render(request, 'faq.html')


def page_404(request, exception=None):
    return render(request, '404.html', status=404)


def page_500(request):
    return render(request, '500.html', status=500)


def page_detail(request, slug):
    """自定义页面 - 管理员创建，通过 /p/<slug>/ 访问"""
    from .models import Page
    from django.http import Http404
    from django.utils.safestring import mark_safe
    from .html_sanitizer import sanitize_html
    page = Page.objects.filter(slug=slug, is_published=True).first()
    if not page:
        raise Http404('页面不存在')
    from site_app.seo_middleware import set_request_seo
    desc = (page.content or '')[:160] + ('...' if len(page.content or '') > 160 else '')
    set_request_seo(request, title=page.title, description=desc)
    # HTML 内容经净化后输出，防 XSS
    content_safe = mark_safe(sanitize_html(page.content)) if page.content_is_html else None
    return render(request, 'page.html', {'page': page, 'content_safe': content_safe})


def games(request):
    game = request.GET.get('g', '')
    if game not in ('snake', 'memory', 'guess'):
        game = ''
    return render(request, 'games.html', {'game': game})


@login_required
def profile(request):
    posts = BbsPost.objects.filter(user=request.user).order_by('-id')[:50]
    snippets = CodeSnippet.objects.filter(user=request.user).order_by('-id')[:50]
    return render(request, 'profile.html', {'posts': posts, 'snippets': snippets})


@staff_member_required
def admin_panel(request):
    stats = {
        'users': User.objects.count(),
        'bbs': BbsPost.objects.count(),
        'code': CodeSnippet.objects.count(),
        'articles': Article.objects.count(),
    }
    return render(request, 'admin/index.html', {'stats': stats})


@staff_member_required
def admin_users(request):
    users = User.objects.all().order_by('-id')[:200]
    return render(request, 'admin/users.html', {'users': users})


@staff_member_required
def admin_bbs(request):
    items = BbsPost.objects.select_related('user').order_by('-id')[:200]
    return render(request, 'admin/bbs.html', {'items': items})


@staff_member_required
def admin_bbs_approve(request, pk):
    if request.method != 'POST':
        return redirect('admin_bbs')
    post = get_object_or_404(BbsPost, pk=pk)
    post.approved = True
    post.save()
    from django.contrib import messages
    messages.success(request, '帖子已通过审核')
    return redirect('admin_bbs')


@staff_member_required
def admin_code(request):
    items = CodeSnippet.objects.select_related('user').order_by('-id')[:200]
    return render(request, 'admin/code.html', {'items': items})


@staff_member_required
def admin_logs(request):
    logs = AdminLog.objects.all().order_by('-id')[:100]
    return render(request, 'admin/logs.html', {'logs': logs})


@staff_member_required
def admin_settings(request):
    """管理员设置 - 站点、安全、用户、内容、维护"""
    from .settings_service import get_all_by_category, set, seed_defaults, DEFAULTS
    seed_defaults()
    tab = request.GET.get('tab', 'general')
    if request.method == 'POST':
        tab = request.POST.get('tab', 'general')
        for key, (default, cat) in DEFAULTS.items():
            if cat == tab:
                val = request.POST.get(key, default)
                set(key, val, cat)
        from django.contrib import messages
        messages.success(request, '设置已保存')
        return redirect(f'{request.path}?tab={tab}')
    data = get_all_by_category()
    themes = [{'id': 'default', 'name': '默认（暖色纸本）'}]
    try:
        from vaelor.theme import list_themes
        extra = list_themes()
        if extra:
            themes = themes + [t for t in extra if t.get('id') != 'default']
    except Exception:
        pass
    return render(request, 'admin/settings.html', {'data': data, 'tab': tab, 'themes': themes})
